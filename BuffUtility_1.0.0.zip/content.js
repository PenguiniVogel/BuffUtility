var Cookie;
(function (Cookie) {
    Cookie.KEY_BUFF_UTILITY_SELECTED_CURRENCY = 'buff_utility_selected_currency';
    function read(name) {
        var result = new RegExp("(?:^|; )" + encodeURIComponent(name) + "=([^;]*)").exec(document.cookie);
        return result ? result[1] : null;
    }
    Cookie.read = read;
    function write(name, value, days) {
        if (days === void 0) { days = 365 * 20; }
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        document.cookie = name + "=" + value + "; expires=" + date.toUTCString() + "; path=/";
    }
    Cookie.write = write;
})(Cookie || (Cookie = {}));
var BuffUtility;
(function (BuffUtility) {
    var currencyTable = {
        'USD': ['$', 0.16],
        'EUR': ['€', 0.13]
    };
    var selectedCurrency = 0;
    var currencySelection;
    function init() {
        console.info('[BuffUtility] Initialized.');
        var cookieValue = 0;
        try {
            cookieValue = parseInt(Cookie.read(Cookie.KEY_BUFF_UTILITY_SELECTED_CURRENCY));
        }
        catch (_a) {
            console.info('[BuffUtility] Cookie was not found.');
            Cookie.write(Cookie.KEY_BUFF_UTILITY_SELECTED_CURRENCY, '0');
        }
        selectedCurrency = cookieValue;
        addCurrencySelection();
        setInterval(function () {
            if (window.location.href.indexOf('/sell_order/on_sale') > -1) {
                convertSellPrice();
            }
            else {
                convertMarketPrice();
            }
        }, 1000);
    }
    BuffUtility.init = init;
    function addCurrencySelection() {
        var nav = document.querySelector('div.nav.nav_entries');
        var currencyDiv = document.createElement('div');
        currencyDiv.setAttribute('style', 'position: relative; float: right;');
        var options = '';
        var currencies = Object.keys(currencyTable);
        for (var i = 0, l = currencies.length; i < l; i++) {
            options += "<option" + (i == selectedCurrency ? ' selected' : '') + ">" + currencies[i] + "</option>";
        }
        currencySelection = document.createElement('select');
        currencySelection.innerHTML = options;
        currencySelection.onchange = function () {
            console.info("[BuffUtility] Currency changed -> " + currencySelection.selectedOptions.item(0).innerText);
            Cookie.write(Cookie.KEY_BUFF_UTILITY_SELECTED_CURRENCY, "" + currencySelection.selectedIndex);
            updateConvertedCurrency();
        };
        currencyDiv.append(currencySelection);
        nav.prepend(currencyDiv);
    }
    function convertCurrency(yuan) {
        var _a, _b, _c;
        var selectedCur = (_c = (_b = (_a = currencySelection.selectedOptions) === null || _a === void 0 ? void 0 : _a.item(0)) === null || _b === void 0 ? void 0 : _b.innerText) !== null && _c !== void 0 ? _c : 'USD';
        return "~" + currencyTable[selectedCur][0] + " " + (yuan * currencyTable[selectedCur][1]).toFixed(2);
    }
    function createCurrencyHoverContainer(text, yuan) {
        return "<e title=\"" + convertCurrency(yuan) + "\" data-du-target=\"converted-hover-currency\">" + text + "</e>";
    }
    function readYuan(element) {
        var priceString = element.innerHTML.replace(/¥|<small>|<\/small>/g, '').trim();
        var price = 0.0;
        try {
            price = parseFloat(priceString);
        }
        catch (_a) {
            console.error("[BuffUtility] Price parsing failed for: " + element.innerHTML);
        }
        return price;
    }
    function convertSellPrice() {
        var elements = document.querySelectorAll('p:not([converted]) strong.sell_order_price');
        for (var i = 0, l = elements.length; i < l; i++) {
            var priceElement = elements.item(i);
            var parent_1 = priceElement.parentElement;
            var price = readYuan(priceElement) * 0.975;
            parent_1.setAttribute('converted', '');
            parent_1.innerHTML += "<strong style=\"color: #eea20e; font-size: 11px;\">" + createCurrencyHoverContainer("(\u00A5 " + price.toFixed(2) + ")", price) + "</strong>";
        }
    }
    function convertMarketPrice() {
        var elements = document.querySelectorAll('li p:not([converted]) strong.f_Strong, td div:not([converted]) strong.f_Strong');
        for (var i = 0, l = elements.length; i < l; i++) {
            var strong = elements.item(i);
            var parent_2 = strong.parentElement;
            parent_2.setAttribute('converted', '');
            var price = readYuan(strong);
            strong.innerHTML = createCurrencyHoverContainer(strong.innerHTML, price);
        }
    }
    function updateConvertedCurrency() {
        convertSellPrice();
        convertMarketPrice();
        var hovers = document.querySelectorAll('e[data-du-target="converted-hover-currency"]');
        for (var i = 0, l = hovers.length; i < l; i++) {
            var e = hovers.item(i);
            e.setAttribute('title', convertCurrency(readYuan(e)));
        }
    }
})(BuffUtility || (BuffUtility = {}));
BuffUtility.init();
